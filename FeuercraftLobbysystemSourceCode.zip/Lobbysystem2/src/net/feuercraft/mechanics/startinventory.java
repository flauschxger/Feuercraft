package net.feuercraft.mechanics;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public class startinventory {
	
	
	public static void setStartInv(Player p) {
		p.getInventory().clear();
		ItemStack Navigator = new ItemStack(Material.COMPASS);
		ItemMeta NaviMeta = Navigator.getItemMeta();
		NaviMeta.setDisplayName("�6Navigator");
		Navigator.setItemMeta(NaviMeta);
		
		ItemStack Hide = new ItemStack(Material.BLAZE_ROD);
		ItemMeta HideMeta = Hide.getItemMeta();
		HideMeta.setDisplayName("�6Spielersichtbarkeit");
		Hide.setItemMeta(HideMeta);
		
		ItemStack Settings = new ItemStack(Material.CHEST);
		ItemMeta SetMeta = Settings.getItemMeta();
		SetMeta.setDisplayName("�1E�2f�3f�4e�5k�6t�7e");
		Settings.setItemMeta(SetMeta);
		
		ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (byte) 3);
		SkullMeta skullMeta = (SkullMeta) skull.getItemMeta();
		skullMeta.setOwner(p.getName());
		skull.setItemMeta(skullMeta);
		
		p.getInventory().setItem(0, Navigator);
		p.getInventory().setItem(1, Hide);
		p.getInventory().setItem(7, Settings);
		p.getInventory().setItem(8, skull);
	}
}
