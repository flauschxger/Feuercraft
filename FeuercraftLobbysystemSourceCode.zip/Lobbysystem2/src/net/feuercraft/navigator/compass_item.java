package net.feuercraft.navigator;



import java.io.File;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import net.feuercraft.main.main;

public class compass_item implements Listener {
	
	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		try {
			if(e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Navigator")) {
				Inventory inv = Bukkit.createInventory(null, 9, "�6Navigator");
				p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
				ItemStack ffa = new ItemStack(Material.SAPLING);
				ItemMeta ffameta = ffa.getItemMeta();
				ffameta.setDisplayName("�6FreeBuild ");
				ffa.setItemMeta(ffameta);
				
				ItemStack ffa1 = new ItemStack(Material.BED);
				ItemMeta ffameta1 = ffa1.getItemMeta();
				ffameta1.setDisplayName("�6BedWars ");
				ffa1.setItemMeta(ffameta1);
				
				ItemStack ffa2 = new ItemStack(Material.GRASS);
				ItemMeta ffameta2 = ffa2.getItemMeta();
				ffameta2.setDisplayName("�6SkyWars ");
				ffa2.setItemMeta(ffameta2);
				
				ItemStack ffa21 = new ItemStack(Material.FIREBALL);
				ItemMeta ffameta21 = ffa21.getItemMeta();
				ffameta21.setDisplayName("�6Spawn ");
				ffa21.setItemMeta(ffameta21);
				
				ItemStack ffa22 = new ItemStack(Material.DIAMOND_SWORD);
				ItemMeta ffameta22 = ffa22.getItemMeta();
				ffameta22.setDisplayName("�6 1vs1 ");
				ffa22.setItemMeta(ffameta22);
				
				inv.setItem(0, ffa);
				inv.setItem(1, ffa1);
				inv.setItem(4, ffa21);
				inv.setItem(7, ffa2);
				inv.setItem(8, ffa22);
				p.openInventory(inv);
				
			}
		}catch(Exception e1) {
			
		}
	}
	@EventHandler
	public void onClick(InventoryClickEvent e) {
		Player p = (Player)e.getWhoClicked();
		try {
		if(e.getInventory().getName().equalsIgnoreCase("�6Navigator")) {
			e.setCancelled(true);
		if(e.getCurrentItem().getType() == Material.SAPLING) {
			File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
			YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
			String world = cfg.getString("Spawn1.WeltName");
			double x = cfg.getDouble("Spawn1.X");
			double y = cfg.getDouble("Spawn1.Y");
			double z = cfg.getDouble("Spawn1.Z");
			double yaw = cfg.getDouble("Spawn1.Yaw");
			double pitch = cfg.getDouble("Spawn1.Pitch");
			Location loc = new Location(Bukkit.getWorld(world), x, y, z);
			loc.setYaw((float)yaw);
			loc.setPitch((float)pitch);
			p.teleport(loc);
			p.sendMessage(main.Prefix + "�aDu wurdest zu FreeBuild teleportiert! ");
			p.closeInventory();
		}else if(e.getCurrentItem().getType() == Material.BED) {
			File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
			YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
			String world = cfg.getString("Spawn2.WeltName");
			double x = cfg.getDouble("Spawn2.X");
			double y = cfg.getDouble("Spawn2.Y");
			double z = cfg.getDouble("Spawn2.Z");
			double yaw = cfg.getDouble("Spawn2.Yaw");
			double pitch = cfg.getDouble("Spawn2.Pitch");
			Location loc = new Location(Bukkit.getWorld(world), x, y, z);
			loc.setYaw((float)yaw);
			loc.setPitch((float)pitch);
			p.teleport(loc);
			p.sendMessage(main.Prefix + "�aDu wurdest zu BedWars teleportiert! ");
			p.closeInventory();
		}else if(e.getCurrentItem().getType() == Material.FIREBALL) {
			File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
			YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
			String world = cfg.getString("Spawn.WeltName");
			double x = cfg.getDouble("Spawn.X");
			double y = cfg.getDouble("Spawn.Y");
			double z = cfg.getDouble("Spawn.Z");
			double yaw = cfg.getDouble("Spawn.Yaw");
			double pitch = cfg.getDouble("Spawn.Pitch");
			Location loc = new Location(Bukkit.getWorld(world), x, y, z);
			loc.setYaw((float)yaw);
			loc.setPitch((float)pitch);
			p.teleport(loc);
			p.sendMessage(main.Prefix + "�aDu wurdest zum Spawn teleportiert! ");
			p.closeInventory();
		}else if(e.getCurrentItem().getType() == Material.GRASS) {
			File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
			YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
			String world = cfg.getString("Spawn3.WeltName");
			double x = cfg.getDouble("Spawn3.X");
			double y = cfg.getDouble("Spawn3.Y");
			double z = cfg.getDouble("Spawn3.Z");
			double yaw = cfg.getDouble("Spawn3.Yaw");
			double pitch = cfg.getDouble("Spawn3.Pitch");
			Location loc = new Location(Bukkit.getWorld(world), x, y, z);
			loc.setYaw((float)yaw);
			loc.setPitch((float)pitch);
			p.teleport(loc);
			p.sendMessage(main.Prefix + "�aDu wurdest zu SkyWars teleportiert! ");
			p.closeInventory();
		}else if(e.getCurrentItem().getType() == Material.DIAMOND_SWORD) {
			File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
			YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
			String world = cfg.getString("Spawn4.WeltName");
			double x = cfg.getDouble("Spawn4.X");
			double y = cfg.getDouble("Spawn4.Y");
			double z = cfg.getDouble("Spawn4.Z");
			double yaw = cfg.getDouble("Spawn4.Yaw");
			double pitch = cfg.getDouble("Spawn4.Pitch");
			Location loc = new Location(Bukkit.getWorld(world), x, y, z);
			loc.setYaw((float)yaw);
			loc.setPitch((float)pitch);
			p.teleport(loc);
			p.sendMessage(main.Prefix + "�aDu wurdest zu 1vs1 teleportiert! ");
			p.closeInventory();
		}
		}
	
			}catch(Exception e1) {
			
		}
	}

}
