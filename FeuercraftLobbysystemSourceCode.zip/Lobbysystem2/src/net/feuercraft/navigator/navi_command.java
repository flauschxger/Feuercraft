package net.feuercraft.navigator;

import java.io.File;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import net.feuercraft.main.main;

public class navi_command implements Listener {

	@EventHandler
	public void onPlayer(PlayerCommandPreprocessEvent e) {
		Player p = e.getPlayer();
		if(e.getMessage().equalsIgnoreCase("/setspawn 1")) {
			if(p.hasPermission("lobbysystem.admin")) {
				File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
				YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
				cfg.set("Spawn1.X,", p.getLocation().getX());
				cfg.set("Spawn1.Y,", p.getLocation().getY());
				cfg.set("Spawn1.Z,", p.getLocation().getZ());
				cfg.set("Spawn1.Yaw", p.getLocation().getYaw());
				cfg.set("Spawn1.Pitch", p.getLocation().getPitch());
				cfg.set("Spawn1.WeltName", p.getWorld().getName());
				try {
					cfg.save(file);
				} catch (Exception e1) {
					p.sendMessage(main.Prefix + "Ein Fehler ist aufgetreten! Starte bitte den Server neu! ");
					return;
				}
				p.sendMessage(main.Prefix + "�aDu hast den Spawn f�r 'Spawn 1' festgelegt! ");
			}else {
				p.sendMessage(main.NoPerm);
			}
		}else if (e.getMessage().equalsIgnoreCase("/setspawn 2")) {
			if(p.hasPermission("lobbysystem.admin")) {
				File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
				YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
				cfg.set("Spawn2.X,", p.getLocation().getX());
				cfg.set("Spawn2.Y,", p.getLocation().getY());
				cfg.set("Spawn2.Z,", p.getLocation().getZ());
				cfg.set("Spawn2.Yaw", p.getLocation().getYaw());
				cfg.set("Spawn2.Pitch", p.getLocation().getPitch());
				cfg.set("Spawn2.WeltName", p.getWorld().getName());
				try {
					cfg.save(file);
				} catch (Exception e1) {
					p.sendMessage(main.Prefix + "Ein Fehler ist aufgetreten! Starte bitte den Server neu! ");
				}
				p.sendMessage(main.Prefix + "�aDu hast den Spawn f�r 'Spawn 2' festgelegt! ");
			}else {
				p.sendMessage(main.NoPerm);
			}
			
		}else if (e.getMessage().equalsIgnoreCase("/setspawn 3")) {
			if(p.hasPermission("lobbysystem.admin")) {
				File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
				YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
				cfg.set("Spawn3.X,", p.getLocation().getX());
				cfg.set("Spawn3.Y,", p.getLocation().getY());
				cfg.set("Spawn3.Z,", p.getLocation().getZ());
				cfg.set("Spawn3.Yaw", p.getLocation().getYaw());
				cfg.set("Spawn3.Pitch", p.getLocation().getPitch());
				cfg.set("Spawn3.WeltName", p.getWorld().getName());
				try {
					cfg.save(file);
				} catch (Exception e1) {
					p.sendMessage(main.Prefix + "Ein Fehler ist aufgetreten! Starte bitte den Server neu! ");
				}
				p.sendMessage(main.Prefix + "�aDu hast den Spawn f�r 'Spawn 3' festgelegt! ");
			}else {
				p.sendMessage(main.NoPerm);
			}
			
		}else if (e.getMessage().equalsIgnoreCase("/setspawn 4")) {
			if(p.hasPermission("lobbysystem.admin")) {
				File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
				YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
				cfg.set("Spawn4.X,", p.getLocation().getX());
				cfg.set("Spawn4.Y,", p.getLocation().getY());
				cfg.set("Spawn4.Z,", p.getLocation().getZ());
				cfg.set("Spawn4.Yaw", p.getLocation().getYaw());
				cfg.set("Spawn4.Pitch", p.getLocation().getPitch());
				cfg.set("Spawn4.WeltName", p.getWorld().getName());
				try {
					cfg.save(file);
				} catch (Exception e1) {
					p.sendMessage(main.Prefix + "Ein Fehler ist aufgetreten! Starte bitte den Server neu! ");
				}
				p.sendMessage(main.Prefix + "�aDu hast den Spawn f�r 'Spawn 4' festgelegt! ");
			}else {
				p.sendMessage(main.NoPerm);
			}
		}else if (e.getMessage().equalsIgnoreCase("/setspawn")) {
			if(p.hasPermission("lobbysystem.admin")) {
				File file = new File("plugins//FeuercraftLobbysystem//spawns.yml");
				YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
				cfg.set("Spawn.X,", p.getLocation().getX());
				cfg.set("Spawn.Y,", p.getLocation().getY());
				cfg.set("Spawn.Z,", p.getLocation().getZ());
				cfg.set("Spawn.Yaw", p.getLocation().getYaw());
				cfg.set("Spawn.Pitch", p.getLocation().getPitch());
				cfg.set("Spawn.WeltName", p.getWorld().getName());
				try {
					cfg.save(file);
				} catch (Exception e1) {
					p.sendMessage(main.Prefix + "Ein Fehler ist aufgetreten! Starte bitte den Server neu! ");
				}
				p.sendMessage(main.Prefix + "�aDu hast den Spawn f�r 'Spawn' festgelegt! ");
			}else {
				p.sendMessage(main.NoPerm);
			}
	}

	}
}
