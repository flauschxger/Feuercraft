package net.feuercraft.main;

public class CONFIGURATION {

}
