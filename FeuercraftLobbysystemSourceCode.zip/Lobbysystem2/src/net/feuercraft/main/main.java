package net.feuercraft.main;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import net.feuercraft.listener.join;
import net.feuercraft.listener.quit;
import net.feuercraft.navigator.compass_item;
import net.feuercraft.navigator.navi_command;

public class main extends JavaPlugin{
	public static String Prefix = "�8[Lobbysystem�8] ";
	public static String NoPerm = Prefix + "�c Du hast nicht gen�gend Rechte um diese Funktion zu nutzen! ";
	public void onEnable() {
		Bukkit.getConsoleSender().sendMessage(Prefix + "�aLobbysystem wird geladen...");
		try {
			register();	
		}catch(Exception e1) {
			Bukkit.getConsoleSender().sendMessage(Prefix + "�aLobbysystem �4hat einen Fehler!");
			return;
		}
		Bukkit.getConsoleSender().sendMessage(Prefix + "�aLobbysystem wurde erfolgreich geladen!");
	}
	public void onDisable() {
		Bukkit.getConsoleSender().sendMessage(Prefix + "�cLobbysystem wurde gestoppt!");
	}
	public void register() {
		Bukkit.getPluginManager().registerEvents(new join(), this);
		Bukkit.getPluginManager().registerEvents(new compass_item(), this);
		Bukkit.getPluginManager().registerEvents(new navi_command(), this);
		Bukkit.getPluginManager().registerEvents(new quit(), this);
	}

}
