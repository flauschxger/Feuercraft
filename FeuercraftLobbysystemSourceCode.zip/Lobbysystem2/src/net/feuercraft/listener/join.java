package net.feuercraft.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import net.feuercraft.main.main;
import net.feuercraft.mechanics.startinventory;

public class join implements Listener{
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();
		
		e.setJoinMessage(main.Prefix + "�6" + p.getName() + "�e hat den Server betreten!");
		//SETSPAWN / SPAWN COMMAND
		
		startinventory.setStartInv(p);
		
		
			
	}

}