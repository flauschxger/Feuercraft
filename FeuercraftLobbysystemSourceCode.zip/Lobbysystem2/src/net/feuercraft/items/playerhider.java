package net.feuercraft.items;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.feuercraft.main.main;

public class playerhider implements Listener{
	
	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		try {
			if(e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
				if(e.getItem().getItemMeta().getDisplayName().equals("�6Spielersichtbarkeit ")) {
				Inventory inv = Bukkit.createInventory(null, InventoryType.HOPPER, "�bSpielersichtbarkeit ");
				ItemStack show = new ItemStack(Material.REDSTONE_BLOCK);
				ItemMeta smeta = show.getItemMeta();
				smeta.setDisplayName("�4Spieler verstecken ");
				show.setItemMeta(smeta);
				
				ItemStack hide = new ItemStack(Material.EMERALD_BLOCK);
				ItemMeta smeta1 = hide.getItemMeta();
				smeta1.setDisplayName("�aSpieler anzeigen ");
				hide.setItemMeta(smeta1);
				
				inv.setItem(1, show);
				inv.setItem(3, hide);
				Player p = e.getPlayer();
				p.openInventory(inv);
				p.playSound(p.getLocation(), Sound.VILLAGER_YES, 1, 1);
				
			}
			}
		}catch(Exception e1) {
		}
	}
	
	@EventHandler
	public void onClick(InventoryClickEvent e) {
		Player p = (Player)e.getWhoClicked();
		if(e.getInventory().getName().equalsIgnoreCase("�bSpielersichtbarkeit")) {
			p.playSound(p.getLocation(),  Sound.CHICKEN_EGG_POP, 1, 1);
			if(e.getCurrentItem().getType() == Material.REDSTONE_BLOCK) {
				for(Player all : Bukkit.getOnlinePlayers()) {
					p.hidePlayer(all);
					p.sendMessage(main.Prefix + "�6Alle Spieler sind nun unsichtbar! ");
					p.closeInventory();
				}
			}else if(e.getCurrentItem().getType() == Material.EMERALD_BLOCK) {
				for(Player all : Bukkit.getOnlinePlayers()) {
					p.showPlayer(all);
					p.sendMessage(main.Prefix + "�6Alle Spieler sind nun wieder sichtbar! ");
					p.closeInventory();
				}
			}
		}
	}

}
